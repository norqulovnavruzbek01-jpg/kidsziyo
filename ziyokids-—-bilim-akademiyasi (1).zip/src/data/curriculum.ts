import { SubjectInfo } from '../types';

export const SUBJECTS: SubjectInfo[] = [
  {
    id: 'matematika',
    title: 'Matematika',
    icon: 'Calculator',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-900',
    description: 'Sonlar siri, tenglamalar, mantiqiy masalalar va geometriya olami.',
    lessonsCount: 12,
    topics: [
      {
        id: 'mat-1',
        title: 'Kasrlar va ularning sirlari',
        summary: 'Oddiy va o\'nli kasrlar ustida amallar, hayotiy misollar.',
        content: `Kasrlar – butunning qismlarini ifodalovchi sonlardir. Masalan, bir butun pitsani 4 ta teng qismga bo'lsak, har bir qism 1/4 (to'rtdan bir) bo'ladi.\n\n• Surat – kasr chizig'idan yuqoridagi son (nechta qism olingani).\n• Maxraj – kasr chizig'idan pastdagi son (butun nechta qismga bo'lingani).\n\nMisol: 1/2 + 1/4 = 3/4. Do'stlaringiz bilan pitsa bo'lishayotganda kasrlar juda qo'l keladi!`,
        quiz: [
          {
            id: 1,
            question: "1/2 va 1/4 sonlarining yig'indisi nechaga teng?",
            options: ["3/4", "2/6", "1/6", "4/5"],
            correctIndex: 0,
            explanation: "1/2 ni 2 ga ko'paytirib maxrajni 4 qilamiz: 2/4 + 1/4 = 3/4."
          },
          {
            id: 2,
            question: "Agar 1 kg olma 12 000 so'm tursa, 1.5 kg olma qancha turadi?",
            options: ["15 000 so'm", "18 000 so'm", "20 000 so'm", "14 000 so'm"],
            correctIndex: 1,
            explanation: "1 kg = 12 000, 0.5 kg = 6 000. Jami: 12 000 + 6 000 = 18 000 so'm."
          }
        ]
      },
      {
        id: 'mat-2',
        title: 'Tezlik, vaqt va masofa',
        summary: 'S = v × t formulasi yordamida qiziqarli masalalar yechish.',
        content: `Fizika va matematikada harakatni tushunish juda muhim:\n• S – Masofa (kilometr yoki metr)\n• v – Tezlik (km/soat yoki m/s)\n• t – Vaqt (soat yoki sekund)\n\nAsosiy qoida: Masofani topish uchun tezlikni vaqtga ko'paytiramiz (S = v × t).`,
        quiz: [
          {
            id: 1,
            question: "Mashina 60 km/soat tezlik bilan 3 soatda qancha masofa bosib o'tadi?",
            options: ["120 km", "180 km", "200 km", "90 km"],
            correctIndex: 1,
            explanation: "S = 60 × 3 = 180 km."
          }
        ]
      }
    ]
  },
  {
    id: 'ona-tili',
    title: 'Ona tili',
    icon: 'BookOpen',
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900',
    description: 'O\'zbek tilining boy grammatikasi, imlo qoidalari va chiroyli nutq.',
    lessonsCount: 10,
    topics: [
      {
        id: 'ot-1',
        title: 'So\'z turkumlari: Ot, sifat va fe\'l',
        summary: 'Nutqimizning asosiy qurilish bloklari.',
        content: `O'zbek tilida so'zlar ma'no va vazifasiga ko'ra so'z turkumlariga bo'linadi:\n\n1. Ot – narsa va buyumlarning nomini bildiriradi (Kitob, bola, Toshkent).\n2. Sifat – belgini bildiriradi (Qizil, aqlli, katta).\n3. Fe'l – harakat va holatni bildiradi (O'qidi, yugurdi, o'ylamoqda).\n\nTo'g'ri va savodli yozish uchun ularni bir-biridan farqlay olish muhim!`,
        quiz: [
          {
            id: 1,
            question: "\"Yaltiroq yulduz osmonda porladi\" gapida fe'l so'z turkumini toping.",
            options: ["Yaltiroq", "Yulduz", "Osmonda", "Porladi"],
            correctIndex: 3,
            explanation: "\"Porladi\" so'zi harakatni bildirgani uchun fe'l hisoblanadi."
          },
          {
            id: 2,
            question: "Qaysi so'z sifat turkumiga kiradi?",
            options: ["Daftar", "Chiroyli", "Yugurdi", "Maktab"],
            correctIndex: 1,
            explanation: "\"Chiroyli\" narsaning belgisini bildirgani uchun sifatdir."
          }
        ]
      }
    ]
  },
  {
    id: 'adabiyot',
    title: 'Adabiyot',
    icon: 'Feather',
    color: 'text-amber-600',
    bgColor: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900',
    description: 'Buyuk shoirlarimiz ijodi, ertaklar, hikmatlar va o\'lmas dostonlar.',
    lessonsCount: 8,
    topics: [
      {
        id: 'ad-1',
        title: 'Alisher Navoiy va uning hikmatlari',
        summary: 'Buyuk mutafakkir asarlari va ibratli hikmatli so\'zlar.',
        content: `Hazrat Alisher Navoiy o'zbek adabiyotining ulug' namoyandasidir. Uning \"Xamsa\" dostoni jahon adabiyoti durdonalaridan sanaladi.\n\nNavoiyning mashhur hikmatlaridan biri: \"Tilga e'tibor – elga e'tibor\". Bu ona tilimizni e'zozlash naqadar muhimligini ko'rsatadi.`,
        quiz: [
          {
            id: 1,
            question: "Alisher Navoiy qaysi buyuk dostonlar majmuasini yaratgan?",
            options: ["Xamsa", "Boburnoma", "Qutadg'u bilig", "Alpomish"],
            correctIndex: 0,
            explanation: "Alisher Navoiy 5 ta dostondan iborat \"Xamsa\"ni yozgan."
          }
        ]
      }
    ]
  },
  {
    id: 'informatika',
    title: 'Informatika',
    icon: 'Cpu',
    color: 'text-violet-600',
    bgColor: 'bg-violet-50 dark:bg-violet-950/40 border-violet-200 dark:border-violet-900',
    description: 'Kompyuter savodxonligi, mantiqiy fikrlash, algoritmlar va dasturlash asoslari.',
    lessonsCount: 12,
    topics: [
      {
        id: 'inf-1',
        title: 'Algoritm nima?',
        summary: 'Kundalik hayotimiz va kompyuter uchun qadam-baqadam ko\'rsatmalar.',
        content: `Algoritm – ma'lum bir maqsadga erishish yoki masalani yechish uchun bajariladigan ketma-ket qoidalar va ko'rsatmalar tizimidir.\n\nMasalan, choy damlash ham algoritm:\n1. Choynakka suv quyish.\n2. Choynakni qaynlatish.\n3. Dam solish.\n\nKompyuterlar ham aynan shunday mantiqiy buyruqlar (dasturlar) asosida ishlaydi!`,
        quiz: [
          {
            id: 1,
            question: "Algoritm so'zining asl kelib chiqishi qaysi buyuk allomaga borib taqaladi?",
            options: ["Al-Xorazmiy", "Ibn Sino", "Al-Beruniy", "Mirzo Ulug'bek"],
            correctIndex: 0,
            explanation: "Algoritm so'zi buyuk vatandoshimiz Muhammad al-Xorazmiy nomidan kelib chiqqan."
          }
        ]
      }
    ]
  },
  {
    id: 'ingliz-tili',
    title: 'Ingliz tili',
    icon: 'Globe',
    color: 'text-rose-600',
    bgColor: 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900',
    description: 'Xalqaro muloqot tili, qiziqarli so\'zlar, grammatika va suhbatlar.',
    lessonsCount: 15,
    topics: [
      {
        id: 'eng-1',
        title: 'Present Simple Tense (Hozirgi oddiy zamon)',
        summary: 'Kundalik odatlarimiz va doimiy harakatlarni ifodalash.',
        content: `Present Simple zamoni har kuni takrorlanadigan ish-harakatlar yoki umumiy haqiqatlarni bildiradi.\n\n• I work (Men ishlayman)\n• You read (Sen o'qiysan)\n• He / She / It readS (U o'qidi - 3-shaxs birlikda fe'lga -s qo'shimchasi qo'shiladi!)\n\nSavol berish uchun Do yoki Does yordamchi fe'llari ishlatiladi.`,
        quiz: [
          {
            id: 1,
            question: "\"She ___ to school every day\" gapiga mos so'zni tanlang.",
            options: ["go", "goes", "going", "gone"],
            correctIndex: 1,
            explanation: "3-shaxs birlik (She) uchun Present Simple'da fe'lga -es/-s qo'shiladi: goes."
          }
        ]
      }
    ]
  },
  {
    id: 'uzb-tarixi',
    title: 'O\'zbekiston tarixi',
    icon: 'Landmark',
    color: 'text-amber-700',
    bgColor: 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-900',
    description: 'Buyuk ipak yo\'li, qadimiy shaharlar, sarkardalar va ilm-fan markazlari.',
    lessonsCount: 10,
    topics: [
      {
        id: 'uzb-1',
        title: 'Buyuk Ipak Yo\'li va qadimiy Samarqand',
        summary: 'Sharq va G\'arbni bog\'lagan afsonaviy savdo yo\'li.',
        content: `Buyuk Ipak yo'li – qadimda Osiyoni Yevropa bilan bog'lagan karvon yo'llari tarmog'i edi. Bu yo'l orqali faqat ipak emas, balki shoyi, ziravorlar, qog'oz tayyorlash sirlari va ilm-fan yutuqlari ham almashilgan.\n\nSamarqand, Buxoro va Xiva kabi shaharlar bu yo'lning eng yorqin gavhari bo'lgan.`,
        quiz: [
          {
            id: 1,
            question: "Buyuk Ipak yo'li qaysi qit'alarni bog'lagan?",
            options: ["Osiyo va Yevropa", "Afrika va Avstraliya", "Shimoliy va Janubiy Amerika", "Antarktida"],
            correctIndex: 0,
            explanation: "Buyuk Ipak yo'li Osiyo va Yevropani o'zaro bog'lagan asosiy savdo arteriyasi edi."
          }
        ]
      }
    ]
  },
  {
    id: 'jahon-tarixi',
    title: 'Jahon tarixi',
    icon: 'Compass',
    color: 'text-cyan-600',
    bgColor: 'bg-cyan-50 dark:bg-cyan-950/40 border-cyan-200 dark:border-cyan-900',
    description: 'Qadimgi sivilizatsiyalar, buyuk kashfiyotlar va insoniyat taraqqiyoti.',
    lessonsCount: 10,
    topics: [
      {
        id: 'jah-1',
        title: 'Qadimgi Misr va Ehromlar',
        summary: 'Nil daryosi bo\'yida gullab-yashnashgan sivilizatsiya sirlari.',
        content: `Qadimgi Misr sivilizatsiyasi Nil daryosi vodiysida miloddan avvalgi 4-ming yillikda vujudga kelgan. Misrliklar o'ziga xos ieroglif yozuvini yaratgan va ulkan ehromlar (piramidalar) qurishgan.\n\nFarg'ona vodiysi va boshqa mintaqalar bilan ham savdo aloqalari bo'lgan.`,
        quiz: [
          {
            id: 1,
            question: "Qadimgi Misr sivilizatsiyasi qaysi daryo bo'yida joylashgan?",
            options: ["Nil", "Sirdaryo", "Amudaryo", "Amazonka"],
            correctIndex: 0,
            explanation: "Misr sivilizatsiyasi Nil daryosi havzasida rivojlangan."
          }
        ]
      }
    ]
  },
  {
    id: 'geografiya',
    title: 'Geografiya',
    icon: 'Map',
    color: 'text-emerald-700',
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-900',
    description: 'Qit\'alar, okeanlar, tabiat hodisalari va ona sayyoramiz sirlari.',
    lessonsCount: 10,
    topics: [
      {
        id: 'geo-1',
        title: 'Yer yuzining okeanlari va qit\'alari',
        summary: 'Sayyoramizning geografik tuzilishi.',
        content: `Yer yuzining asosiy qismi suvdan iborat. Dunyoda 6 ta qit'a va 4 ta asosiy okean mavjud:\n\n• Qit'alar: Yevrosiyo, Afrika, Shimoliy Amerika, Janubiy Amerika, Avstraliya va Antarktida.\n• Okeanlar: Tinch, Atlantika, Hind va Shimoliy Muziy okeanlari.`,
        quiz: [
          {
            id: 1,
            question: "Yer yuzidagi eng katta okean qaysi?",
            options: ["Tinch okeani", "Atlantika okeani", "Hind okeani", "Shimoliy Muziy okeani"],
            correctIndex: 0,
            explanation: "Tinch okeani yer yuzidagi eng katta va chuqur okean hisoblanadi."
          }
        ]
      }
    ]
  },
  {
    id: 'fizika',
    title: 'Fizika',
    icon: 'Zap',
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-50 dark:bg-yellow-950/40 border-yellow-200 dark:border-yellow-900',
    description: 'Tabiat qonunlari, kuch, energiya, yorug\'lik va elektr toki olami.',
    lessonsCount: 10,
    topics: [
      {
        id: 'fiz-1',
        title: 'Tortishish kuchi va Nyuton qonunlari',
        summary: 'Nima uchun olmalar yerga tushadi?',
        content: `Tortishish kuchi (gravitatsiya) – barcha jismning bir-biriga intilish kuchi. Nyuton olma daraxti ostida o'tirib, nima uchun olma osmonga emas, yerga tushishini o'ylab bu qonuniyatni kashf etgan.\n\nYerimiz bizni va barcha narsalarni o'ziga tortib turadi!`,
        quiz: [
          {
            id: 1,
            question: "Tortishish kuchini kim kashf etgan?",
            options: ["Isak Nyuton", "Albert Eynshteyn", "Galileo Galiley", "Tomas Edison"],
            correctIndex: 0,
            explanation: "Isak Nyuton umumjahon tortishish qonunini kashf etgan."
          }
        ]
      }
    ]
  }
];
